В консоли перейти в папку с .jar файлом. В папке должен лежать source.xml. И установлена Java runtime invironment.
команда java -jar xml2json_v01.jar -f source.xml
